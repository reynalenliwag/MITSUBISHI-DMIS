CD-ROM DOS driver installation instructions:
============================================

Your Digital HiNote VP700 Series notebook is equipped with a CD-ROM / floppy
combined unit. Nothing needs to be done to access the CD-ROM drive from
Windows 95 and there are no performance issues when using Windows 95.

However, depending on the VP700 Series model that you purchased, one of three
different CD-ROM models may be installed. When booting to DOS, best performance 
is obtained by using a specified DOS CD-ROM driver, as described below.

The CD-ROM drives are:
        TORiSAN CDR U200, TORiSAN CDR U240 and TOSHIBA XM-1702BC (24x)

These drivers are all located in the sub-directory, C:\CDROM.

The lines required to use the DOS CD-ROM drivers are already contained in the
files AUTOEXEC.BAT and CONFIG.SYS in the root directory of the C: drive.
However, these lines are 'REM'ed out. All the user need do is determine which
of the three possible drives is actually installed on the system, and remove
the "REM " from the appropriate lines (one each in AUTOEXEC.BAT and CONFIG.SYS).

Step 1.  Determine which CD-ROM drive is installed in your system.

    1a.  Use Device Manager (from Windows 95), Right-click on 'My Computer',
         then click on 'Properties', then click on 'Device Manager' tab and
         click on 'CD-ROM'. The text that appears below that line should be
         similar one of the three options in Step 3 below.
    1b.  With the system shut down and power off, remove the CD-ROM/floppy
         combo unit. (Refer to documentation to find the release button, if
         necessary.) The label should indicate the model information that
         will be similar to one of the 3 options in Step 3 below.

Step 2.  Edit AUTOEXEC.BAT and remove the "REM " preceding 'C:\WINDOWS\...'

        AUTOEXEC.BAT:
        =============
        chg:    REM C:\WINDOWS\COMMAND\MSCDEX.EXE /D:CDROM1
        to:     C:\WINDOWS\COMMAND\MSCDEX.EXE /D:CDROM1

Step 3.
        Edit CONFIG.SYS and remove the "REM " preceding 'DEVICE=C:\...', but
        only for the CD-ROM device in your system, as determined in Step 1.

	PLEASE DO NOT REMOVE "REM " FROM MORE THAN ONE LINE!!

	CONFIG.SYS:
        ===========
a.        for   TORiSAN CDR U200 (20x)
                ----------------------
        chg:    REM DEVICE=C:\TSY\TRICD.SYS /D:CDROM1
        to:     DEVICE=C:\TSY\TRICD.SYS /D:CDROM1

b.        for   TORiSAN CDR U240 (24x)
                ----------------------
        chg:    REM DEVICE=C:\TSY\TSYCDROM.SYS /D:CDROM1
        to:     DEVICE=C:\TSY\TSYCDROM.SYS /D:CDROM1

c.        for   TOSHIBA XM-1702BC (24x)
                -----------------------
        chg:    REM DEVICE=C:\TSY\CDROMDRV.SYS /D:CDROM1
        to:     DEVICE=C:\TSY\CDROMDRV.SYS /D:CDROM1